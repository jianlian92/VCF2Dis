#!/bin/sh
#$ -S /bin/sh
echo Start Time : 
date
echo g++ -g  -O3	src/VCF2Dis.cpp	-lgzstream	-lz	-L	src/gzstream/	-L	src/zlib/	-o	bin/VCF2Dis
g++ -g  -O3	src/VCF2Dis.cpp	-lgzstream	-lz	-L	src/gzstream/	-L	src/zlib/	-o	bin/VCF2Dis	
echo End Time :
date
